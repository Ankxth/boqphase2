"""Parses a SAP-style "Work Order" PDF (the KPIL/Provident BOQ-with-rates
format -- "BOQ SUMMARY" pages followed by a "BOQ ITEM DETAILS" section with
one row per priced line item) into a flat list of line items: Activity
Number, Tax Tariff Code, Unit, Rate, Amount, and a derived Quantity.

Why derive Quantity as Amount / Rate instead of reading it directly
--------------------------------------------------------------------
pdftotext -layout reconstructs each PDF page as plain text by aligning
words into columns using their x/y position. For most rows that works
cleanly (Unit, Qty, Rate, Amount all end up on one line together). But
whenever a row's Qty or Description is wide enough to push layout
recompute, the Qty *number* gets detached onto its own line -- sometimes
the line right before the "Sr No / Code" line, sometimes right after,
sometimes split across two fragments (e.g. "15633.13" then a lone "0" on
the next line). There is no reliable, general rule for which detached
line a stray Qty number belongs to.

Rate and Amount do NOT have this problem: in every real example checked
across this document (420 pages, 7,910 line-item occurrences), Rate and
Amount always land together on the same physical line as the row's Unit
token, even when Qty itself is detached elsewhere. And the row's own
math is exact: Amount == Qty * Rate (confirmed to the cent). So instead
of trying to locate a possibly-detached Qty token, this parser reads
Unit + the LAST TWO decimal-point numbers found on that Unit's line
(Rate, then Amount, always in that order -- Amount is the rightmost/
widest column so it's never itself split leftward), and derives
Qty = Amount / Rate.

Validated against this document's own numbers, not just spot-checked:
the WO's "BOQ SUMMARY" section states each top-level section's total
Amount and a grand total. Summing every individually parsed line item's
Amount from "BOQ ITEM DETAILS" reproduces that grand total EXACTLY (to
the cent, 0.00 difference) across all 420 pages -- see
scripts/test_wo_pdf_parser.py.

System dependency
------------------
Requires the `pdftotext` binary (poppler-utils) on PATH -- e.g.
`apt-get install poppler-utils` on Debian/Ubuntu. This is the same tool
already used for reading the Hindalco sustainability-report PDFs during
this project's emission-factor sourcing work, so it should already be
available wherever those scripts ran; it is NOT a pip package.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

CODE_RE = re.compile(r"\b(\d{7,9})\s*/\s*(\d{5,6})\b")

# Base Unit of Measure vocabulary seen across the Provident master item
# code dataset. Longest-first so e.g. FT2/FT3 match before bare FT, and
# M3/M2 match before bare M.
_UNIT_TOKENS = [
    "NOS", "LS", "RMT", "SQM", "CUM", "SET", "MON", "FT2", "EA", "KG", "LOT",
    "DAY", "MT", "KGS", "FT3", "FT", "L", "HR", "BAG", "FLR", "UNT", "KM",
    "M3", "LOD", "M2", "ROL", "ACR", "BOX", "PAA", "KW", "TRP", "HRS", "FLT",
    "TON", "Shf", "M", "N",
]
UNIT_RE = re.compile(r"\b(" + "|".join(re.escape(u) for u in sorted(set(_UNIT_TOKENS), key=len, reverse=True)) + r")\b")
NUM_RE = re.compile(r"\d[\d,]*\.\d+")
SUMMARY_LINE_RE = re.compile(r"^\s*(\d+)\s+(.+?)\s{2,}([\d,]+\.\d{2})\s*$", re.M)


def _parse_amt(s: str) -> float:
    return float(s.replace(",", ""))


@dataclass
class WoLineItem:
    code: str
    taxcode: str
    unit: str
    rate: float
    amount: float
    qty: float  # derived: amount / rate -- see module docstring


@dataclass
class WoParseResult:
    items: list[WoLineItem]
    unparsed_code_occurrences: list[tuple[str, str, str]]  # (code, taxcode, context snippet)
    summary_grand_total: Optional[float]  # from the WO's own "BOQ SUMMARY" section, for validation
    total_amount_parsed: float


def _pdf_to_text(pdf_path: str) -> str:
    # encoding="utf-8" explicitly -- pdftotext writes UTF-8 to stdout
    # regardless of platform, but subprocess's text=True without an
    # explicit encoding decodes using the OS's default locale encoding.
    # On Windows that's cp1252, which chokes (UnicodeDecodeError, killing
    # the reader thread and leaving result.stdout as None) on real
    # characters this WO's text contains, e.g. a stray "Â" from a
    # mis-encoded non-breaking space in "CementÂ Screed Concrete
    # Flooring". errors="replace" is a second safety net in case a PDF
    # ever contains something pdftotext itself doesn't emit as clean
    # UTF-8 -- better to substitute the odd byte than crash the whole
    # parse over one stray character deep in a description string that
    # doesn't affect any code/unit/rate/amount extraction anyway.
    result = subprocess.run(
        ["pdftotext", "-layout", pdf_path, "-"],
        capture_output=True, text=True, check=True,
        encoding="utf-8", errors="replace",
    )
    return result.stdout


def parse_work_order_pdf(pdf_path: str) -> WoParseResult:
    """Extracts every priced BOQ line item from a Work Order PDF of this
    format. Raises FileNotFoundError if pdftotext isn't installed, or
    subprocess.CalledProcessError if the PDF can't be read as text (e.g.
    a scanned/image-only PDF -- this parser does not OCR).
    """
    text = _pdf_to_text(str(pdf_path))

    summary_grand_total = None
    if "BOQ ITEM DETAILS" in text:
        summary_text = text[: text.index("BOQ ITEM DETAILS")]
        summary_matches = SUMMARY_LINE_RE.findall(summary_text)
        if summary_matches:
            summary_grand_total = sum(_parse_amt(m[2]) for m in summary_matches)
        detail_text = text[text.index("BOQ ITEM DETAILS"):]
    else:
        # Fall back to treating the whole document as the detail section
        # if the expected header isn't present (e.g. a different export).
        detail_text = text

    code_matches = list(CODE_RE.finditer(detail_text))

    items: list[WoLineItem] = []
    unparsed: list[tuple[str, str, str]] = []

    for i, m in enumerate(code_matches):
        code, taxcode = m.group(1), m.group(2)
        window_end = code_matches[i + 1].start() if i + 1 < len(code_matches) else len(detail_text)
        line_start = detail_text.rfind("\n", 0, m.start()) + 1
        window = detail_text[line_start:window_end]

        unit = rate = amount = None
        for line in window.split("\n"):
            um = UNIT_RE.search(line)
            if um is None:
                continue
            nums = NUM_RE.findall(line)
            if len(nums) < 2:
                continue
            unit = um.group(1)
            rate = _parse_amt(nums[-2])
            amount = _parse_amt(nums[-1])
            break

        if unit is None or rate is None or amount is None or rate == 0:
            unparsed.append((code, taxcode, window[:200].replace("\n", " | ")))
            continue

        items.append(WoLineItem(code=code, taxcode=taxcode, unit=unit, rate=rate, amount=amount, qty=amount / rate))

    total_amount_parsed = sum(it.amount for it in items)

    return WoParseResult(
        items=items,
        unparsed_code_occurrences=unparsed,
        summary_grand_total=summary_grand_total,
        total_amount_parsed=total_amount_parsed,
    )